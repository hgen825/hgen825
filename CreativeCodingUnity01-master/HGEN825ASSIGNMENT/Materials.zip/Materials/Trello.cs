﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class Trello
{
	public string id { get; set; }
	public string createdAt { get; set;} 
	public string updatedAt { get; set; }
	public string version { get; set; }
	public string AddedAt { get; set; }
	public string Title { get; set; }
	public string Description { get; set; }
	public string ListName { get; set; }
	public string BoardName { get; set; }
	public string CreaterFullName { get; set; }
	public string CreaterUsername { get; set; }
	public string CardURL { get; set; }
}
